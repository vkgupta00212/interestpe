class PayHistoryModel{
  String upiId;
  String type;
  String dati;
  String amount;


  PayHistoryModel(this.upiId,this.type,this.dati,this.amount);
}