class ChatModel{
  String name;
  String time;
  String currentMessage;

  ChatModel(this.name,this.time,this.currentMessage);
}