class MyRoutes {
  static String loginRoute = "/login";
  static String homeRoute = "/home";
  static String navBar = "/navbar";
  static String otp = "/Otp";
  static String individualChat = "/IndividualChat";
  }